﻿Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase
Add-Type -AssemblyName System.Windows.Forms

$scale = 2
$spriteWidth = 96
$spriteHeight = 96
$baseWindowSize = 260
$floorY = 26
$zoomSteps = @(0.75, 1.0, 1.35, 1.7)
$assetPath = Join-Path $PSScriptRoot "panda-reference.png"

$palette = @{
  "." = "Transparent"
  "o" = "#151515"
  "w" = "#f3f0df"
  "s" = "#d7d1bd"
  "b" = "#272624"
  "e" = "#050505"
  "p" = "#e9a7a0"
  "g" = "#6fb66f"
  "d" = "#3f7c48"
  "c" = "#8fd3c4"
}

$brushConverter = [Windows.Media.BrushConverter]::new()
$pandaBitmap = New-Object Windows.Media.Imaging.BitmapImage
$pandaBitmap.BeginInit()
$pandaBitmap.CacheOption = [Windows.Media.Imaging.BitmapCacheOption]::OnLoad
$pandaBitmap.UriSource = [Uri]::new($assetPath, [UriKind]::Absolute)
$pandaBitmap.EndInit()
$pandaBitmap.Freeze()

function New-EmptySprite {
  $grid = New-Object 'char[][]' $spriteHeight
  for ($y = 0; $y -lt $spriteHeight; $y++) {
    $grid[$y] = New-Object 'char[]' $spriteWidth
    for ($x = 0; $x -lt $spriteWidth; $x++) { $grid[$y][$x] = "." }
  }
  return $grid
}

function Set-SpritePixel($grid, [int]$x, [int]$y, [char]$value) {
  if ($x -ge 0 -and $x -lt $spriteWidth -and $y -ge 0 -and $y -lt $spriteHeight) {
    $grid[$y][$x] = $value
  }
}

function Fill-Ellipse($grid, [double]$cx, [double]$cy, [double]$rx, [double]$ry, [char]$value) {
  for ($y = [Math]::Floor($cy - $ry); $y -le [Math]::Ceiling($cy + $ry); $y++) {
    for ($x = [Math]::Floor($cx - $rx); $x -le [Math]::Ceiling($cx + $rx); $x++) {
      $dx = ($x - $cx) / $rx
      $dy = ($y - $cy) / $ry
      if (($dx * $dx + $dy * $dy) -le 1.0) { Set-SpritePixel $grid $x $y $value }
    }
  }
}

function Fill-Heart($grid, [double]$cx, [double]$cy, [double]$size, [char]$value) {
  Fill-Ellipse $grid ($cx - $size * 0.32) ($cy - $size * 0.18) ($size * 0.35) ($size * 0.32) $value
  Fill-Ellipse $grid ($cx + $size * 0.32) ($cy - $size * 0.18) ($size * 0.35) ($size * 0.32) $value
  for ($y = [int]($cy - $size * 0.05); $y -le [int]($cy + $size * 0.72); $y++) {
    $half = [Math]::Max(0, ($size * 0.62) - (($y - $cy) * 0.78))
    for ($x = [int]($cx - $half); $x -le [int]($cx + $half); $x++) {
      Set-SpritePixel $grid $x $y $value
    }
  }
}

function Draw-Line($grid, [int]$x1, [int]$y1, [int]$x2, [int]$y2, [char]$value) {
  $steps = [Math]::Max([Math]::Abs($x2 - $x1), [Math]::Abs($y2 - $y1))
  if ($steps -eq 0) { Set-SpritePixel $grid $x1 $y1 $value; return }
  for ($i = 0; $i -le $steps; $i++) {
    $t = $i / $steps
    Set-SpritePixel $grid ([Math]::Round($x1 + ($x2 - $x1) * $t)) ([Math]::Round($y1 + ($y2 - $y1) * $t)) $value
  }
}

function Convert-Sprite($grid) {
  $rows = @()
  for ($y = 0; $y -lt $spriteHeight; $y++) { $rows += -join $grid[$y] }
  return $rows
}

function New-PandaSprite([string]$variant) {
  $grid = New-EmptySprite

  Fill-Ellipse $grid 27 18 17 16 "b"
  Fill-Ellipse $grid 69 18 17 16 "b"
  Fill-Heart $grid 27 18 7 "w"
  Fill-Heart $grid 69 18 7 "w"

  Fill-Ellipse $grid 48 42 38 32 "o"
  Fill-Ellipse $grid 48 43 34 28 "w"
  Fill-Ellipse $grid 48 24 16 6 "o"

  Fill-Ellipse $grid 32 41 12 15 "b"
  Fill-Ellipse $grid 64 41 12 15 "b"

  if ($variant -eq "sleep") {
    Draw-Line $grid 24 39 38 42 "o"
    Draw-Line $grid 58 42 72 39 "o"
  }

  foreach ($line in @(@(19,31,13,26), @(20,36,12,35), @(22,42,14,45), @(77,31,83,26), @(76,36,84,35), @(74,42,82,45))) {
    Draw-Line $grid $line[0] $line[1] $line[2] $line[3] "o"
  }

  Fill-Heart $grid 48 51 6 "b"
  Fill-Ellipse $grid 24 55 4 3 "p"
  Fill-Ellipse $grid 72 55 4 3 "p"

  Fill-Ellipse $grid 48 72 25 20 "b"
  Fill-Ellipse $grid 48 73 17 15 "w"
  Fill-Ellipse $grid 26 72 9 17 "b"
  Fill-Ellipse $grid 70 72 9 17 "b"
  Fill-Ellipse $grid 35 89 11 5 "b"
  Fill-Ellipse $grid 61 89 11 5 "b"

  if ($variant -eq "squish") {
    Fill-Ellipse $grid 48 77 31 14 "b"
    Fill-Ellipse $grid 48 76 20 10 "w"
  }

  return Convert-Sprite $grid
}

$pandaBase = New-PandaSprite "base"
$pandaSleep = New-PandaSprite "sleep"
$pandaSquish = New-PandaSprite "squish"

$window = New-Object Windows.Window
$window.Width = $baseWindowSize
$window.Height = $baseWindowSize
$window.WindowStyle = "None"
$window.AllowsTransparency = $true
$window.Background = "Transparent"
$window.Topmost = $true
$window.ShowInTaskbar = $false
$window.ResizeMode = "NoResize"
$window.Left = 80
$window.Top = 80
$window.Title = "Codex Panda Pet"

$canvas = New-Object Windows.Controls.Canvas
$canvas.Width = $baseWindowSize
$canvas.Height = $baseWindowSize
$canvas.Background = [Windows.Media.Brushes]::Transparent

$viewbox = New-Object Windows.Controls.Viewbox
$viewbox.Stretch = "Fill"
$viewbox.Child = $canvas
$window.Content = $viewbox

$state = [ordered]@{
  Mode = "idle"
  Facing = 1
  Velocity = 0.0
  Started = Get-Date
  DurationMs = 1800
  Frame = 0
  RollAngle = 0.0
  Dragging = $false
  DragStart = $null
  WindowStartLeft = 0.0
  WindowStartTop = 0.0
  Zoom = 1.0
  ZoomIndex = 1
  ActiveScreenDevice = ""
  DragMoved = $false
  DragStartWindowLeft = 0.0
  DragStartWindowTop = 0.0
  Speech = ""
}

$spriteCache = @{}

function Get-RandomRange([double]$min, [double]$max) {
  return $min + (Get-Random) / [int]::MaxValue * ($max - $min)
}

function Set-PandaMode([string]$mode) {
  $state.Mode = $mode
  $state.Started = Get-Date
  $state.Frame = 0
  $state.RollAngle = 0
  $state.Speech = ""

  if ($mode -eq "walk") {
    $state.DurationMs = Get-Random -Minimum 1800 -Maximum 3600
    $state.Facing = @(-1, 1) | Get-Random
    $state.Velocity = $state.Facing * (Get-RandomRange 0.35 0.85)
  } elseif ($mode -eq "roll") {
    $state.DurationMs = Get-Random -Minimum 3200 -Maximum 6200
    $state.Facing = @(-1, 1) | Get-Random
    $state.Velocity = $state.Facing * (Get-RandomRange 3.2 5.6)
  } elseif ($mode -eq "eat") {
    $state.DurationMs = Get-Random -Minimum 1800 -Maximum 3200
    $state.Velocity = 0
  } elseif ($mode -eq "sleep") {
    $state.DurationMs = Get-Random -Minimum 2600 -Maximum 5600
    $state.Velocity = 0
  } elseif ($mode -eq "surprise") {
    $state.DurationMs = Get-Random -Minimum 650 -Maximum 950
    $state.Velocity = 0
    $state.Speech = "!"
  } elseif ($mode -eq "sway") {
    $state.DurationMs = Get-Random -Minimum 1800 -Maximum 3200
    $state.Velocity = 0
  } elseif ($mode -eq "tilt") {
    $state.DurationMs = Get-Random -Minimum 1500 -Maximum 2600
    $state.Velocity = 0
    $state.Speech = "?"
  } elseif ($mode -eq "shake") {
    $state.DurationMs = Get-Random -Minimum 700 -Maximum 1200
    $state.Velocity = 0
  } elseif ($mode -eq "bounce") {
    $state.DurationMs = Get-Random -Minimum 1100 -Maximum 1900
    $state.Velocity = 0
  } elseif ($mode -eq "react") {
    $state.DurationMs = Get-Random -Minimum 1300 -Maximum 2400
    $state.Velocity = 0
    $pandaPower = -join ([char[]](0x30d1, 0x30f3, 0x30c0, 0x3055, 0x3093, 0x30d1, 0x30ef, 0x30fc, 0xff01))
    $state.Speech = @("...", ">", "?", $pandaPower) | Get-Random
  } else {
    $state.DurationMs = Get-Random -Minimum 1200 -Maximum 2600
    $state.Velocity = 0
  }
}

function Get-NextMode {
  $n = Get-Random -Minimum 0 -Maximum 100
  if ($n -lt 18) { return "roll" }
  if ($n -lt 30) { return "walk" }
  if ($n -lt 42) { return "eat" }
  if ($n -lt 52) { return "sleep" }
  if ($n -lt 62) { return "sway" }
  if ($n -lt 72) { return "tilt" }
  if ($n -lt 81) { return "shake" }
  if ($n -lt 90) { return "bounce" }
  if ($n -lt 97) { return "react" }
  return "idle"
}

function Set-PetZoom([double]$zoom) {
  $oldWidth = $window.Width
  $oldHeight = $window.Height
  $zoom = [Math]::Max(0.55, [Math]::Min(2.25, $zoom))
  $state.Zoom = $zoom
  $window.Width = $baseWindowSize * $zoom
  $window.Height = $baseWindowSize * $zoom
  $window.Left -= ($window.Width - $oldWidth) / 2
  $window.Top -= ($window.Height - $oldHeight) / 2
}

function Set-NextZoomStep {
  $state.ZoomIndex = ($state.ZoomIndex + 1) % $zoomSteps.Count
  Set-PetZoom $zoomSteps[$state.ZoomIndex]
}

function Get-ScreenBoundsInWpfUnits {
  $screens = [System.Windows.Forms.Screen]::AllScreens
  $physicalLeft = ($screens | ForEach-Object { $_.Bounds.Left } | Measure-Object -Minimum).Minimum
  $physicalTop = ($screens | ForEach-Object { $_.Bounds.Top } | Measure-Object -Minimum).Minimum
  $physicalRight = ($screens | ForEach-Object { $_.Bounds.Right } | Measure-Object -Maximum).Maximum
  $physicalBottom = ($screens | ForEach-Object { $_.Bounds.Bottom } | Measure-Object -Maximum).Maximum

  $scaleX = [Windows.SystemParameters]::VirtualScreenWidth / ($physicalRight - $physicalLeft)
  $scaleY = [Windows.SystemParameters]::VirtualScreenHeight / ($physicalBottom - $physicalTop)
  $virtualLeft = [Windows.SystemParameters]::VirtualScreenLeft
  $virtualTop = [Windows.SystemParameters]::VirtualScreenTop

  return $screens | ForEach-Object {
    $bounds = $_.WorkingArea
    $left = $virtualLeft + (($bounds.Left - $physicalLeft) * $scaleX)
    $top = $virtualTop + (($bounds.Top - $physicalTop) * $scaleY)
    $right = $virtualLeft + (($bounds.Right - $physicalLeft) * $scaleX)
    $bottom = $virtualTop + (($bounds.Bottom - $physicalTop) * $scaleY)

    [pscustomobject]@{
      Device = $_.DeviceName
      Left = [double]$left
      Top = [double]$top
      Right = [double]$right
      Bottom = [double]$bottom
    }
  }
}

function Get-ScreenBoundsByDevice([string]$deviceName) {
  if ($deviceName) {
    foreach ($screenBounds in Get-ScreenBoundsInWpfUnits) {
      if ($screenBounds.Device -eq $deviceName) { return $screenBounds }
    }
  }
  return $null
}

function Get-CurrentScreenInfo {
  $centerX = $window.Left + ($window.Width / 2)
  $centerY = $window.Top + ($window.Height / 2)
  $nearest = $null
  $nearestDistance = [double]::MaxValue

  foreach ($screenBounds in Get-ScreenBoundsInWpfUnits) {
    if ($centerX -ge $screenBounds.Left -and $centerX -le $screenBounds.Right -and $centerY -ge $screenBounds.Top -and $centerY -le $screenBounds.Bottom) {
      return $screenBounds
    }

    $screenCenterX = ($screenBounds.Left + $screenBounds.Right) / 2
    $screenCenterY = ($screenBounds.Top + $screenBounds.Bottom) / 2
    $distance = [Math]::Pow($centerX - $screenCenterX, 2) + [Math]::Pow($centerY - $screenCenterY, 2)
    if ($distance -lt $nearestDistance) {
      $nearestDistance = $distance
      $nearest = $screenBounds
    }
  }

  return $nearest
}

function Clamp-ToActiveScreen {
  $screenBounds = Get-ScreenBoundsByDevice $state.ActiveScreenDevice
  if ($null -eq $screenBounds) {
    $screenBounds = Get-CurrentScreenInfo
    $state.ActiveScreenDevice = $screenBounds.Device
  }

  $hitHorizontalEdge = $false
  $maxLeft = $screenBounds.Right - $window.Width
  $maxTop = $screenBounds.Bottom - $window.Height

  if ($maxLeft -lt $screenBounds.Left) { $maxLeft = $screenBounds.Left }
  if ($maxTop -lt $screenBounds.Top) { $maxTop = $screenBounds.Top }

  if ($window.Left -lt $screenBounds.Left) {
    $window.Left = $screenBounds.Left
    $hitHorizontalEdge = $true
  } elseif ($window.Left -gt $maxLeft) {
    $window.Left = $maxLeft
    $hitHorizontalEdge = $true
  }

  if ($window.Top -lt $screenBounds.Top) {
    $window.Top = $screenBounds.Top
  } elseif ($window.Top -gt $maxTop) {
    $window.Top = $maxTop
  }

  return $hitHorizontalEdge
}

function Stop-AtScreenEdge {
  $state.Velocity = 0
  $state.RollAngle = 0
  if ($state.Mode -eq "roll" -or $state.Mode -eq "walk") {
    Set-PandaMode "idle"
  }
}

function Add-Pixel([int]$x, [int]$y, [string]$color, [Windows.Controls.Canvas]$target) {
  if ($color -eq "Transparent") { return }
  $rect = New-Object Windows.Shapes.Rectangle
  $rect.Width = $scale
  $rect.Height = $scale
  $rect.Fill = $brushConverter.ConvertFromString($color)
  [Windows.Controls.Canvas]::SetLeft($rect, $x * $scale)
  [Windows.Controls.Canvas]::SetTop($rect, $y * $scale)
  [void]$target.Children.Add($rect)
}

function Add-TextBubble([string]$text, [double]$left, [double]$top) {
  $isLongText = $text.Length -gt 3
  if ($isLongText) {
    $left = 34
    $top = 8
  }

  $bubble = New-Object Windows.Controls.Border
  $bubble.Background = $brushConverter.ConvertFromString("#eef4e9")
  $bubble.BorderBrush = $brushConverter.ConvertFromString("#333833")
  $bubble.BorderThickness = 1
  $bubble.CornerRadius = 7
  $bubble.Padding = "8,3,8,3"
  $bubble.MaxWidth = if ($isLongText) { 190 } else { 72 }

  $label = New-Object Windows.Controls.TextBlock
  $label.Text = $text
  $label.FontFamily = "Consolas"
  $label.FontSize = if ($isLongText) { 14 } else { 15 }
  $label.Foreground = $brushConverter.ConvertFromString("#1d2521")
  $label.TextWrapping = "Wrap"
  $bubble.Child = $label

  $bubble.Measure([Windows.Size]::new($baseWindowSize, $baseWindowSize))
  $measuredWidth = $bubble.DesiredSize.Width
  if (($left + $measuredWidth) -gt ($baseWindowSize - 8)) {
    $left = [Math]::Max(8, $baseWindowSize - $measuredWidth - 8)
  }

  [Windows.Controls.Canvas]::SetLeft($bubble, $left)
  [Windows.Controls.Canvas]::SetTop($bubble, $top)
  [void]$canvas.Children.Add($bubble)
}

function Add-Bamboo {
  $stem = New-Object Windows.Shapes.Rectangle
  $stem.Width = 10
  $stem.Height = 78
  $stem.Fill = $brushConverter.ConvertFromString("#3f7c48")
  [Windows.Controls.Canvas]::SetLeft($stem, 176)
  [Windows.Controls.Canvas]::SetTop($stem, 124)
  [void]$canvas.Children.Add($stem)

  foreach ($y in 128, 146, 164, 182) {
    $node = New-Object Windows.Shapes.Rectangle
    $node.Width = 14
    $node.Height = 5
    $node.Fill = $brushConverter.ConvertFromString("#6fb66f")
    [Windows.Controls.Canvas]::SetLeft($node, 174)
    [Windows.Controls.Canvas]::SetTop($node, $y)
    [void]$canvas.Children.Add($node)
  }

  foreach ($leaf in @(@(185, 129, 29, 9), @(151, 156, 26, 8), @(185, 175, 24, 8))) {
    $leafShape = New-Object Windows.Shapes.Ellipse
    $leafShape.Width = $leaf[2]
    $leafShape.Height = $leaf[3]
    $leafShape.Fill = $brushConverter.ConvertFromString("#8fd68c")
    [Windows.Controls.Canvas]::SetLeft($leafShape, $leaf[0])
    [Windows.Controls.Canvas]::SetTop($leafShape, $leaf[1])
    [void]$canvas.Children.Add($leafShape)
  }
}

function Add-ClosedMouthOverlay {
  $cover = New-Object Windows.Shapes.Ellipse
  $cover.Width = 86
  $cover.Height = 42
  $cover.Fill = $brushConverter.ConvertFromString("#f8f8f4")
  [Windows.Controls.Canvas]::SetLeft($cover, 87)
  [Windows.Controls.Canvas]::SetTop($cover, 136)
  [void]$canvas.Children.Add($cover)

  $mouth = New-Object Windows.Shapes.Rectangle
  $mouth.Width = 36
  $mouth.Height = 5
  $mouth.RadiusX = 2
  $mouth.RadiusY = 2
  $mouth.Fill = $brushConverter.ConvertFromString("#1f1f1f")
  [Windows.Controls.Canvas]::SetLeft($mouth, 112)
  [Windows.Controls.Canvas]::SetTop($mouth, 152)
  [void]$canvas.Children.Add($mouth)
}

function Add-Shadow {
  $shadow = New-Object Windows.Shapes.Ellipse
  $shadow.Width = 190
  $shadow.Height = 22
  $shadow.Fill = $brushConverter.ConvertFromString("#45000000")
  [Windows.Controls.Canvas]::SetLeft($shadow, 45)
  [Windows.Controls.Canvas]::SetTop($shadow, 224)
  [void]$canvas.Children.Add($shadow)
}

function Add-Sparkle([double]$left, [double]$top) {
  foreach ($offset in @(@(8, 0, 4, 18), @(1, 7, 18, 4))) {
    $spark = New-Object Windows.Shapes.Rectangle
    $spark.Width = $offset[2]
    $spark.Height = $offset[3]
    $spark.Fill = $brushConverter.ConvertFromString("#d7fff5")
    [Windows.Controls.Canvas]::SetLeft($spark, $left + $offset[0])
    [Windows.Controls.Canvas]::SetTop($spark, $top + $offset[1])
    [void]$canvas.Children.Add($spark)
  }
}

function Draw-Panda([string[]]$sprite, [string]$spriteName) {
  if (Test-Path -LiteralPath $assetPath) {
    $image = New-Object Windows.Controls.Image
    $image.Source = $pandaBitmap
    $image.Width = 210
    $image.Height = 190
    $image.Stretch = "Uniform"
    $image.SnapsToDevicePixels = $true
    $image.RenderTransformOrigin = "0.5,0.5"

    $elapsed = ((Get-Date) - $state.Started).TotalMilliseconds
    $visualLeft = 25.0
    $visualTop = 26.0
    $angle = 0.0
    $scaleX = 1.0
    $scaleY = 1.0

    if ($state.Facing -lt 0) { $scaleX *= -1 }

    if ($state.Mode -eq "roll") {
      $angle = $state.RollAngle
    } elseif ($state.Mode -eq "sway") {
      $angle = [Math]::Sin($elapsed / 180.0) * 5
      $visualLeft += [Math]::Sin($elapsed / 210.0) * 4
    } elseif ($state.Mode -eq "tilt") {
      $angle = 12 * $state.Facing
    } elseif ($state.Mode -eq "shake") {
      $visualLeft += [Math]::Sin($elapsed / 28.0) * 8
      $angle = [Math]::Sin($elapsed / 35.0) * 3
    } elseif ($state.Mode -eq "bounce") {
      $visualTop -= [Math]::Abs([Math]::Sin($elapsed / 150.0)) * 22
      $scaleY = 1.0 + [Math]::Abs([Math]::Sin($elapsed / 150.0)) * 0.08
      $scaleX *= 1.0 - [Math]::Abs([Math]::Sin($elapsed / 150.0)) * 0.04
    } elseif ($state.Mode -eq "surprise") {
      $scaleX *= 1.12
      $scaleY = 1.12
      $visualTop -= 10
      $angle = [Math]::Sin($elapsed / 32.0) * 5
    } elseif ($state.Mode -eq "eat") {
      $visualTop += [Math]::Sin($elapsed / 95.0) * 4
      $scaleY = 0.98 + [Math]::Abs([Math]::Sin($elapsed / 120.0)) * 0.05
    } elseif ($state.Mode -eq "sleep") {
      $angle = -5
      $visualTop += 8
      $scaleY = 0.96
    }

    $transformGroup = New-Object Windows.Media.TransformGroup
    if ($scaleX -ne 1.0 -or $scaleY -ne 1.0) {
      [void]$transformGroup.Children.Add((New-Object Windows.Media.ScaleTransform -ArgumentList $scaleX, $scaleY))
    }
    if ($angle -ne 0.0) {
      [void]$transformGroup.Children.Add((New-Object Windows.Media.RotateTransform -ArgumentList $angle))
    }
    if ($transformGroup.Children.Count -gt 0) {
      $image.RenderTransform = $transformGroup
    }

    [Windows.Controls.Canvas]::SetLeft($image, $visualLeft)
    [Windows.Controls.Canvas]::SetTop($image, $visualTop)
    [void]$canvas.Children.Add($image)
    return
  }

  $cacheKey = "$spriteName-$($state.Facing)"
  if (-not $spriteCache.ContainsKey($cacheKey)) {
    $group = New-Object Windows.Controls.Canvas
    $group.Width = $spriteWidth * $scale
    $group.Height = $spriteHeight * $scale

    for ($y = 0; $y -lt $sprite.Count; $y++) {
      for ($x = 0; $x -lt $sprite[$y].Length; $x++) {
        $sourceX = if ($state.Facing -lt 0) { $spriteWidth - $x - 1 } else { $x }
        $key = [string]$sprite[$y][$sourceX]
        Add-Pixel $x $y $palette[$key] $group
      }
    }

    $spriteCache[$cacheKey] = $group
  }

  $group = $spriteCache[$cacheKey]
  if ($state.Mode -eq "roll") {
    $rotate = New-Object Windows.Media.RotateTransform
    $rotate.Angle = $state.RollAngle
    $rotate.CenterX = ($spriteWidth * $scale) / 2
    $rotate.CenterY = ($spriteHeight * $scale) / 2
    $group.RenderTransform = $rotate
  } else {
    $group.RenderTransform = $null
  }

  [Windows.Controls.Canvas]::SetLeft($group, 40)
  [Windows.Controls.Canvas]::SetTop($group, $floorY)
  [void]$canvas.Children.Add($group)
}

function Render {
  $canvas.Children.Clear()
  Add-Shadow

  $sprite = $pandaBase
  $spriteName = "base"
  if ($state.Mode -eq "sleep") {
    $sprite = $pandaSleep
    $spriteName = "sleep"
    Add-TextBubble "Zz" 206 42
  } elseif ($state.Mode -eq "surprise") {
    Add-TextBubble "!" 206 42
  } elseif ($state.Mode -eq "roll") {
    $sprite = $pandaSquish
    $spriteName = "roll"
  } elseif ($state.Mode -eq "eat") {
    if (($state.Frame % 2) -eq 0) {
      $sprite = $pandaBase
      $spriteName = "eat-base"
    } else {
      $sprite = $pandaSquish
      $spriteName = "eat-squish"
    }
  } elseif ($state.Mode -eq "tilt") {
    Add-TextBubble "?" 206 44
  } elseif ($state.Mode -eq "react") {
    Add-TextBubble $state.Speech 198 44
  } elseif ($state.Mode -eq "idle" -and ($state.Frame % 28) -gt 20) {
    Add-TextBubble ">" 210 50
    Add-Sparkle 34 60
  }

  Draw-Panda $sprite $spriteName

  if ($state.Mode -eq "eat") {
    if (($state.Frame % 2) -ne 0) {
      Add-ClosedMouthOverlay
    }
    Add-Bamboo
  }
}

$canvas.Add_MouseLeftButtonDown({
  param($sender, $eventArgs)
  $state.Dragging = $true
  $state.DragStart = $window.PointToScreen($eventArgs.GetPosition($window))
  $state.WindowStartLeft = $window.Left
  $state.WindowStartTop = $window.Top
  $state.DragStartWindowLeft = $window.Left
  $state.DragStartWindowTop = $window.Top
  $state.DragMoved = $false
  $canvas.CaptureMouse() | Out-Null
})

$canvas.Add_MouseMove({
  param($sender, $eventArgs)
  if (-not $state.Dragging) { return }
  $position = $window.PointToScreen($eventArgs.GetPosition($window))
  $window.Left = $state.WindowStartLeft + ($position.X - $state.DragStart.X)
  $window.Top = $state.WindowStartTop + ($position.Y - $state.DragStart.Y)
  if ([Math]::Abs($window.Left - $state.DragStartWindowLeft) -gt 4 -or [Math]::Abs($window.Top - $state.DragStartWindowTop) -gt 4) {
    $state.DragMoved = $true
  }
})

$canvas.Add_MouseLeftButtonUp({
  $state.Dragging = $false
  $canvas.ReleaseMouseCapture()
  $screenInfo = Get-CurrentScreenInfo
  $state.ActiveScreenDevice = $screenInfo.Device
  Clamp-ToActiveScreen | Out-Null
  if ($state.DragMoved) {
    Set-PandaMode "eat"
  } else {
    Set-PandaMode "surprise"
  }
})

$canvas.Add_MouseRightButtonUp({
  Set-NextZoomStep
})

$canvas.Add_MouseWheel({
  param($sender, $eventArgs)
  if ($eventArgs.Delta -gt 0) {
    Set-PetZoom ($state.Zoom + 0.1)
  } else {
    Set-PetZoom ($state.Zoom - 0.1)
  }
})

$timer = New-Object Windows.Threading.DispatcherTimer
$timer.Interval = [TimeSpan]::FromMilliseconds(50)
$timer.Add_Tick({
  $state.Frame += 1
  $elapsed = ((Get-Date) - $state.Started).TotalMilliseconds

  if (-not $state.Dragging) {
    $window.Left += $state.Velocity
  }

  if ([string]::IsNullOrWhiteSpace($state.ActiveScreenDevice)) {
    $state.ActiveScreenDevice = (Get-CurrentScreenInfo).Device
  }

  if (Clamp-ToActiveScreen) {
    Stop-AtScreenEdge
  }

  if ($state.Mode -eq "roll") {
    $state.RollAngle += [Math]::Max(18, [Math]::Abs($state.Velocity) * 8) * $state.Facing
  }

  if ($elapsed -gt $state.DurationMs -and -not $state.Dragging) {
    Set-PandaMode (Get-NextMode)
  }

  Render
})

Set-PandaMode "idle"
Render
$timer.Start()
[void]$window.ShowDialog()
